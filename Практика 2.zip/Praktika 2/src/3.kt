fun main(){
    val num1=45
    val num2=9
    println(num1/num2)
}