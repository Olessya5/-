fun main(){
    val a=4
    val b=5

    if(a % 2 !=0){
        println(a)
    }
    else if(b%2 !=0){
        println(b)
    }
    else{
        println("Оба числа нечётные")
    }
}