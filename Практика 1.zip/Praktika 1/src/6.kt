fun main(){
    val string=("1 13 49")
    println(string)
}