fun main(){
    val num1=23
    val num2=75
    val num3=99
    val num4=41
    println("$num1 $num2 $num3 $num4")
}