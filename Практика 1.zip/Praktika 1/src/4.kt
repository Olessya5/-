fun main(){
    val a=readLine()
    println("Вы ввели число $a")
}