fun main(){
    val a=readLine()
    println(" $a - вот какое число вы ввели")
}