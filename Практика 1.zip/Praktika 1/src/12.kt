fun main(){
    println(77)
    println(944)
    println(2165)
    println(888)
}