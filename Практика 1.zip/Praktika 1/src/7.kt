fun main(){
    val string=("7  15  100")
    println(string)
}