fun main(){
    println("Введите число: ")
    val num1=readLine()
    val num2=readLine()
        val num3=readLine()
    println("$num1  $num2  $num3")


}