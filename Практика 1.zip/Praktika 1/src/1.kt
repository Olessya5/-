fun main(){
    // Целое число
    val age: Int = 25
    println("Возраст: $age")

    // Строка
    val name: String = "Иван"
    println("Имя: $name")

    // Список
    val numbers: List<Int> = listOf(1, 2, 3)
    println("Список чисел: $numbers")
}
