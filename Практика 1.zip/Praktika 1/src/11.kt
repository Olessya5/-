fun main(){
    println(5)
    println(10)
    println(21)
}