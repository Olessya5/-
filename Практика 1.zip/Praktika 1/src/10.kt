fun main(){
    println(50)
    println(10)
}