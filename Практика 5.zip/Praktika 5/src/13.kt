fun main() {
    println("Таблица квадратов:")
    for (i in 1..20) {
        println("$i\t${i * i}")
    }
}