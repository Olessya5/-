fun main() {
    for (i in 1..10) {
        println("${i}^3 = ${i  *  i}")
    }
}