fun main() {
    val text = "Hello, world!"
    for (char in text) {
        println(char)
    }
}